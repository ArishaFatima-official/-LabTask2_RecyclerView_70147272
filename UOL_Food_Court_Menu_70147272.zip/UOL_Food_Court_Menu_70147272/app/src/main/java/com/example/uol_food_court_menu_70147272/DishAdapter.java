package com.example.uol_food_court_menu_70147272;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class DishAdapter
        extends RecyclerView.Adapter<DishAdapter.ViewHolder> {

    public interface OnItemClickListener {
        void onItemClick(int position);
    }

    private ArrayList<Dish> dishes;
    private OnItemClickListener listener;

    public DishAdapter(ArrayList<Dish> dishes,
                       OnItemClickListener listener) {
        this.dishes = dishes;
        this.listener = listener;
    }

    public static class ViewHolder
            extends RecyclerView.ViewHolder {

        ImageView imgDish;
        TextView txtDishName;
        TextView txtDishPrice;

        public ViewHolder(@NonNull View itemView,
                          OnItemClickListener listener) {
            super(itemView);

            // Find views only once
            imgDish = itemView.findViewById(R.id.imgDish);
            txtDishName = itemView.findViewById(R.id.txtDishName);
            txtDishPrice = itemView.findViewById(R.id.txtDishPrice);

            // Report the position of the tapped card
            itemView.setOnClickListener(v -> {
                int position = getBindingAdapterPosition();

                if (position != RecyclerView.NO_POSITION) {
                    listener.onItemClick(position);
                }
            });
        }
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(
            @NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_dish, parent, false);

        return new ViewHolder(view, listener);
    }

    @Override
    public void onBindViewHolder(
            @NonNull ViewHolder holder, int position) {

        Dish dish = dishes.get(position);

        holder.imgDish.setImageResource(dish.getImageResId());
        holder.txtDishName.setText(dish.getName());
        holder.txtDishPrice.setText("Rs. " + dish.getPrice());
    }

    @Override
    public int getItemCount() {
        return dishes.size();
    }
}