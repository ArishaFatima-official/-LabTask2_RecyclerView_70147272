package com.example.uol_food_court_menu_70147272;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class DishDetailActivity extends AppCompatActivity {

    ImageView imgDetailDish;
    TextView txtDetailName;
    TextView txtDetailCategory;
    TextView txtDetailPrice;
    TextView txtDetailDescription;
    Button btnCall;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dish_detail);

        imgDetailDish = findViewById(R.id.imgDetailDish);
        txtDetailName = findViewById(R.id.txtDetailName);
        txtDetailCategory = findViewById(R.id.txtDetailCategory);
        txtDetailPrice = findViewById(R.id.txtDetailPrice);
        txtDetailDescription = findViewById(R.id.txtDetailDescription);
        btnCall = findViewById(R.id.btnCall);

        // Receive the selected dish's data
        Intent intent = getIntent();

        String name = intent.getStringExtra(MainActivity.EXTRA_NAME);
        String category = intent.getStringExtra(MainActivity.EXTRA_CATEGORY);
        String description = intent.getStringExtra(MainActivity.EXTRA_DESCRIPTION);
        String stallPhone = intent.getStringExtra(MainActivity.EXTRA_PHONE);

        int price = intent.getIntExtra(MainActivity.EXTRA_PRICE, 0);
        int imageResId = intent.getIntExtra(MainActivity.EXTRA_IMAGE, 0);

        // Display the received data
        setTitle(name);
        txtDetailName.setText(name);
        txtDetailCategory.setText(category);
        txtDetailPrice.setText("Rs. " + price);
        txtDetailDescription.setText(description);

        if (imageResId != 0) {
            imgDetailDish.setImageResource(imageResId);
        }

        // Call to Order
        btnCall.setOnClickListener(v -> {
            try {
                Intent dialIntent = new Intent(
                        Intent.ACTION_DIAL,
                        Uri.parse("tel:" + stallPhone)
                );

                startActivity(dialIntent);

            } catch (android.content.ActivityNotFoundException e) {
                Toast.makeText(
                        DishDetailActivity.this,
                        "No dialer application found",
                        Toast.LENGTH_SHORT
                ).show();
            }
        });
    }
}