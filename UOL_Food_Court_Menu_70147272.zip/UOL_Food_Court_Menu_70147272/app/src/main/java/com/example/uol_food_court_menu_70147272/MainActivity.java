package com.example.uol_food_court_menu_70147272;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity
        implements DishAdapter.OnItemClickListener {

    // Intent key constants
    public static final String EXTRA_NAME = "dish_name";
    public static final String EXTRA_CATEGORY = "dish_category";
    public static final String EXTRA_DESCRIPTION = "dish_description";
    public static final String EXTRA_PHONE = "dish_phone";
    public static final String EXTRA_PRICE = "dish_price";
    public static final String EXTRA_IMAGE = "dish_image";

    RecyclerView rvMenu;
    ArrayList<Dish> dishes;
    DishAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        rvMenu = findViewById(R.id.rvMenu);

        // Create the list of dishes
        dishes = new ArrayList<>();

        dishes.add(new Dish(
                "Chicken Burger",
                "Fast Food",
                "A juicy chicken burger with fresh vegetables and sauce.",
                "03001234561",
                350,
                R.drawable.dish_burger
        ));

        dishes.add(new Dish(
                "Chicken Pizza",
                "Pizza",
                "A delicious pizza topped with chicken and cheese.",
                "03001234562",
                800,
                R.drawable.dish_pizza
        ));

        dishes.add(new Dish(
                "Chicken Biryani",
                "Pakistani",
                "Spicy chicken biryani served with aromatic rice.",
                "03001234563",
                450,
                R.drawable.dish_biryani
        ));

        dishes.add(new Dish(
                "French Fries",
                "Snacks",
                "Crispy golden fries served with ketchup.",
                "03001234564",
                200,
                R.drawable.dish_fries
        ));

        dishes.add(new Dish(
                "Club Sandwich",
                "Sandwich",
                "A fresh club sandwich with chicken and vegetables.",
                "03001234565",
                400,
                R.drawable.dish_sandwich
        ));

        dishes.add(new Dish(
                "Alfredo Pasta",
                "Pasta",
                "Creamy Alfredo pasta with chicken.",
                "03001234566",
                550,
                R.drawable.dish_pasta
        ));

        dishes.add(new Dish(
                "Chicken Roll",
                "Street Food",
                "A spicy chicken roll wrapped in a soft paratha.",
                "03001234567",
                250,
                R.drawable.dish_roll
        ));

        dishes.add(new Dish(
                "Chicken Shawarma",
                "Fast Food",
                "Chicken shawarma with garlic sauce and vegetables.",
                "03001234568",
                300,
                R.drawable.dish_shawarma
        ));

        // Scenario 1: Two-column grid
        rvMenu.setLayoutManager(  new LinearLayoutManager(this));

        // Attach the adapter
        adapter = new DishAdapter(dishes, this);
        rvMenu.setAdapter(adapter);
    }

    // Scenario 2: A card was tapped
    @Override
    public void onItemClick(int position) {

        // Get the exact dish that was tapped
        Dish dish = dishes.get(position);

        // Explicit Intent to open DishDetailActivity
        Intent intent = new Intent(
                MainActivity.this,
                DishDetailActivity.class
        );

        // Send only the selected dish's data
        intent.putExtra(EXTRA_NAME, dish.getName());
        intent.putExtra(EXTRA_CATEGORY, dish.getCategory());
        intent.putExtra(EXTRA_DESCRIPTION, dish.getDescription());
        intent.putExtra(EXTRA_PHONE, dish.getStallPhone());
        intent.putExtra(EXTRA_PRICE, dish.getPrice());
        intent.putExtra(EXTRA_IMAGE, dish.getImageResId());

        startActivity(intent);
    }
}